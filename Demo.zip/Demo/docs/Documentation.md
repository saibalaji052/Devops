#Development

##Technical documentation Detail

link to documentation in confluence was updated