#Analysis

##Motivation
User needs to be able to access documentation. The documentation should be accsessible from the web application and should describe functionalities of ITRION web application.

###Feature

Documentation page is accesible from ITRION web application
Documentation is searchable
Documentation can be easily created/modified by content creators without developer experience

###Assumptions and Open Items

Tools for creating/presenting documentation are available and should be used, but which tool fits our needs best is to be decided. 