#Study
 
##How this is solved today
Not implemented currently in ITRION.

##Business value [Euro]
In management, business value is an informal term that includes all forms of value that determine the health and well-being of the firm in the long run. Business value expands concept of value of the firm beyond economic value (also known as economic profit, economic value added, and shareholder value) to include other forms of value such as employee value, customer value, supplier value, channel partner value, alliance partner value, managerial value, and societal value. Many of these forms of value are not directly measured in monetary terms. According to the Project Management Institute, business value is the "net quantifiable benefit derived from a business endeavor that may be tangible, intangible, or both."

##Implementation costs [Euro]
Implementation Costs are the Court-approved administrative costs associated with implementing this Agreement, including the fees and costs of the Track A and Track B Neutrals, the Claims Administrator, costs incurred under Section VIII.A.3, and the costs necessary to provide notice of this Agreement to the Class. With the exception of the costs incurred under Section VIII.A.3, Implementation Costs do not include (1) attorneys’ fees, costs, and expenses, (2) the costs and expenses associated with preparing and/or submitting claims on behalf of individual Claimants, (3) the fees, expenses, and costs of the Ombudsman (“Ombudsman Costs”), and (4) costs and expenses incurred by Class Counsel in the performance of their duties under this Agreement.
##Priority
Tired of your never-ending task list and watching your priorities get pushed to the side? Learn how to create a task list, choose a prioritization strategy, schedule your tasks, and communicate with your team to increase productivity and get things done.